﻿Public Class MyCustomControl

End Class
