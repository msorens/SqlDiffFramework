<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LabelTitle = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.ButtonClose = New System.Windows.Forms.Button
        Me.LabelBevel = New System.Windows.Forms.Label
        Me.CommandLink7 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink6 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink5 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink4 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink3 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink2 = New LukeSw.Windows.Forms.CommandLink
        Me.CommandLink1 = New LukeSw.Windows.Forms.CommandLink
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelTitle
        '
        Me.LabelTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelTitle.AutoSize = True
        Me.LabelTitle.BackColor = System.Drawing.Color.Transparent
        Me.LabelTitle.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.LabelTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LabelTitle.Location = New System.Drawing.Point(18, 25)
        Me.LabelTitle.Margin = New System.Windows.Forms.Padding(9, 16, 16, 16)
        Me.LabelTitle.Name = "LabelTitle"
        Me.LabelTitle.Size = New System.Drawing.Size(292, 19)
        Me.LabelTitle.TabIndex = 0
        Me.LabelTitle.Text = "Choose a modal dialog window to show"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.ButtonClose)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 370)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(400, 48)
        Me.Panel1.TabIndex = 8
        '
        'ButtonClose
        '
        Me.ButtonClose.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ButtonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ButtonClose.Location = New System.Drawing.Point(313, 12)
        Me.ButtonClose.Margin = New System.Windows.Forms.Padding(12)
        Me.ButtonClose.Name = "ButtonClose"
        Me.ButtonClose.Size = New System.Drawing.Size(75, 23)
        Me.ButtonClose.TabIndex = 0
        Me.ButtonClose.Text = "Close"
        Me.ButtonClose.UseVisualStyleBackColor = True
        '
        'LabelBevel
        '
        Me.LabelBevel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LabelBevel.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.LabelBevel.Location = New System.Drawing.Point(0, 368)
        Me.LabelBevel.Name = "LabelBevel"
        Me.LabelBevel.Size = New System.Drawing.Size(400, 2)
        Me.LabelBevel.TabIndex = 9
        '
        'CommandLink7
        '
        Me.CommandLink7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink7.Location = New System.Drawing.Point(47, 309)
        Me.CommandLink7.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink7.Name = "CommandLink7"
        Me.CommandLink7.ShowElevationIcon = True
        Me.CommandLink7.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink7.TabIndex = 7
        Me.CommandLink7.Text = "Show system-locking TaskDialog-like window"
        '
        'CommandLink6
        '
        Me.CommandLink6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink6.Location = New System.Drawing.Point(47, 268)
        Me.CommandLink6.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink6.Name = "CommandLink6"
        Me.CommandLink6.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink6.TabIndex = 6
        Me.CommandLink6.Text = "Show expandable TaskDialog-like window"
        '
        'CommandLink5
        '
        Me.CommandLink5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink5.Location = New System.Drawing.Point(47, 227)
        Me.CommandLink5.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink5.Name = "CommandLink5"
        Me.CommandLink5.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink5.TabIndex = 5
        Me.CommandLink5.Text = "Show security TaskDialog-like windows"
        '
        'CommandLink4
        '
        Me.CommandLink4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink4.Location = New System.Drawing.Point(47, 186)
        Me.CommandLink4.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink4.Name = "CommandLink4"
        Me.CommandLink4.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink4.TabIndex = 4
        Me.CommandLink4.Text = "Show customized TaskDialog-like window"
        '
        'CommandLink3
        '
        Me.CommandLink3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink3.Location = New System.Drawing.Point(47, 145)
        Me.CommandLink3.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink3.Name = "CommandLink3"
        Me.CommandLink3.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink3.TabIndex = 3
        Me.CommandLink3.Text = "Show standard TaskDialog-like window"
        '
        'CommandLink2
        '
        Me.CommandLink2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink2.Location = New System.Drawing.Point(47, 104)
        Me.CommandLink2.Margin = New System.Windows.Forms.Padding(3, 0, 3, 0)
        Me.CommandLink2.Name = "CommandLink2"
        Me.CommandLink2.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink2.TabIndex = 2
        Me.CommandLink2.Text = "Show customized MessageBox-like window"
        '
        'CommandLink1
        '
        Me.CommandLink1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.CommandLink1.Location = New System.Drawing.Point(47, 63)
        Me.CommandLink1.Margin = New System.Windows.Forms.Padding(3, 3, 3, 0)
        Me.CommandLink1.Name = "CommandLink1"
        Me.CommandLink1.Size = New System.Drawing.Size(341, 41)
        Me.CommandLink1.TabIndex = 1
        Me.CommandLink1.Text = "Show standard MessageBox-like window"
        '
        'Form1
        '
        Me.AcceptButton = Me.CommandLink1
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.ButtonClose
        Me.ClientSize = New System.Drawing.Size(400, 418)
        Me.Controls.Add(Me.LabelBevel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.LabelTitle)
        Me.Controls.Add(Me.CommandLink7)
        Me.Controls.Add(Me.CommandLink6)
        Me.Controls.Add(Me.CommandLink5)
        Me.Controls.Add(Me.CommandLink4)
        Me.Controls.Add(Me.CommandLink3)
        Me.Controls.Add(Me.CommandLink2)
        Me.Controls.Add(Me.CommandLink1)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.Text = "VDialog Samples"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CommandLink1 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents CommandLink2 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents CommandLink3 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents CommandLink4 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents CommandLink5 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents CommandLink6 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents LabelTitle As System.Windows.Forms.Label
    Friend WithEvents CommandLink7 As LukeSw.Windows.Forms.CommandLink
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ButtonClose As System.Windows.Forms.Button
    Friend WithEvents LabelBevel As System.Windows.Forms.Label

End Class
