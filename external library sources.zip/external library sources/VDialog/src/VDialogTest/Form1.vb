Imports LukeSw.Windows.Forms

Public Class Form1

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        CheckForIllegalCrossThreadCalls = True

    End Sub

    Private Sub CommandLink1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink1.Click
        VDialog.Show(Me, "This is a standard MessageBox-like window.", "Window Caption")
    End Sub

    Private Sub CommandLink2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink2.Click
        VDialog.Show(Me, "Hello World!", "Caption", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2)
    End Sub

    Private Sub CommandLink3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink3.Click
        Dim vd As New VDialog()
        With vd
            .Owner = Me
            .WindowTitle = "WindowTitle"
            .MainInstruction = "Main instruction"
            .Content = "Content"
            .MainIcon = VDialogIcon.Warning
            .Buttons = New VDialogButton() {New VDialogButton(VDialogResult.OK)}
            .Show()
        End With
    End Sub

    Private Sub CommandLink4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink4.Click
        Dim vd As New VDialog()
        With vd
            .Owner = Me
            .WindowTitle = "Some window"
            .MainInstruction = "Please do something"
            .CustomMainIcon = Icon.ToBitmap()
            .Buttons = New VDialogButton() { _
                New VDialogButton(VDialogResult.Ignore), _
                New VDialogButton(VDialogResult.Continue), _
                New VDialogButton(">> Click Me <<", AddressOf Button_Click, True), _
                New VDialogButton(VDialogResult.Cancel)}
            .DefaultButton = VDialogDefaultButton.None
            .Sound = VDialogSound.Security
            .VerificationText = "Check me"
            .Show()
        End With
    End Sub

    Private Sub Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        With DirectCast(sender, Button)
            .Text = "Thank you!"
            .Image = Nothing
            .Enabled = False
        End With
    End Sub

    Private Sub CommandLink5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink5.Click
        Dim vd As New VDialog()
        With vd
            .Owner = Nothing
            .Buttons = New VDialogButton() {New VDialogButton(VDialogResult.OK)}
            .Content = "Please close this window."
            .MainIcon = VDialogIcon.SecuritySuccess
            .MainInstruction = "SecuritySuccess"
            .WindowTitle = "Security Dialog (1/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityQuestion
            .MainInstruction = "SecurityQuestion"
            .WindowTitle = "Security Dialog (2/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityWarning
            .MainInstruction = "SecurityWarning"
            .WindowTitle = "Security Dialog (3/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityError
            .MainInstruction = "SecurityError"
            .WindowTitle = "Security Dialog (4/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityShield
            .MainInstruction = "SecurityShield"
            .WindowTitle = "Security Dialog (5/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityShieldBlue
            .MainInstruction = "SecurityShieldBlue"
            .WindowTitle = "Security Dialog (6/7)"
            .Show()
            .MainIcon = VDialogIcon.SecurityShieldGray
            .MainInstruction = "SecurityShieldGray"
            .WindowTitle = "Security Dialog (7/7)"
            .Show()
        End With
    End Sub

    Private Sub CommandLink6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink6.Click
        Dim vd As New VDialog()
        With vd
            AddHandler .LinkClicked, AddressOf linkClicked
            .Owner = Me
            .Buttons = New VDialogButton() {New VDialogButton(VDialogResult.OK)}
            .WindowTitle = "Another Example"
            .MainInstruction = "Expandable Dialog"
            .MainIcon = VDialogIcon.Information
            .Content = "In this example you can see that there is an additional" & vbCrLf & "footer and some expandable extra information."
            .ContentLinks.Add(.Content.IndexOf("footer"), 6)
            .ContentLinks(0).Name = "Content"
            .FooterIcon = VDialogIcon.Information
            .FooterText = "This is the footer. You can click here."
            .FooterLinks.Add(.FooterText.IndexOf("here"), 4)
            .FooterLinks(0).Name = "Footer"
            .ExpandedControlText = "Hide Extra Info"
            .CollapsedControlText = "Show Extra Info"
            .ExpandedInformation = "Extra Information"
            .ExpandedInformationLinks.Add(.ExpandedInformation.IndexOf("Information"), 11)
            .ExpandedInformationLinks(0).Name = "ExpandedInformation"
            .ExpandFooterArea = True
            .ExpandedByDefault = True
            .Show()
            .RightToLeft = Windows.Forms.RightToLeft.Yes
            .RightToLeftLayout = True
            .ExpandedByDefault = False
            .ExpandFooterArea = False
            .Show()
        End With
    End Sub

    Private Sub linkClicked(ByVal sender As Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)
        VDialog.Show(CType(sender, IWin32Window), "You've clicked the link from the " & e.Link.Name & " label.")
    End Sub

    Private Sub CommandLink7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandLink7.Click
        Dim vd As New VDialog()
        With vd
            .Owner = Me
            .WindowTitle = "UAC-like window"
            .MainInstruction = "You must click OK button to continue"
            .Buttons = New VDialogButton() {New VDialogButton(VDialogResult.OK), New VDialogButton(VDialogResult.Cancel)}
            .MainIcon = VDialogIcon.SecurityShieldBlue
            .DefaultButton = VDialogDefaultButton.None
            .Content = "If you don't know what to do, click Cancel button."
            .LockSystem = True
            .CustomControl = New MyCustomControl()
            .Show()
        End With
    End Sub

    Private Sub ButtonClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ButtonClose.Click
        Close()
    End Sub

End Class
