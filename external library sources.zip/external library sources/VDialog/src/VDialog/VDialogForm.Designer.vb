﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class VDialogForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(VDialogForm))
        Me.TableLayoutPanelContent = New System.Windows.Forms.TableLayoutPanel
        Me.LabelIcon = New System.Windows.Forms.Label
        Me.LabelTitle = New LukeSw.Windows.Forms.Label
        Me.LabelContent = New LukeSw.Windows.Forms.Label
        Me.TableLayoutPanelContents = New System.Windows.Forms.TableLayoutPanel
        Me.LabelExpandedContent = New LukeSw.Windows.Forms.Label
        Me.PanelExpandedFooter = New System.Windows.Forms.Panel
        Me.TableLayoutPanelExpanderFooter = New System.Windows.Forms.TableLayoutPanel
        Me.LabelExpandedFooter = New LukeSw.Windows.Forms.Label
        Me.BevelExpanderFooter = New System.Windows.Forms.Label
        Me.PanelFooter = New System.Windows.Forms.Panel
        Me.TableLayoutPanelFooter = New System.Windows.Forms.TableLayoutPanel
        Me.LabelIconFooter = New System.Windows.Forms.Label
        Me.LabelFooter = New LukeSw.Windows.Forms.Label
        Me.BevelFooter = New System.Windows.Forms.Label
        Me.PanelButtons = New System.Windows.Forms.Panel
        Me.TableLayoutPanelButtons = New System.Windows.Forms.TableLayoutPanel
        Me.FlowLayoutPanelButtons = New System.Windows.Forms.FlowLayoutPanel
        Me.Button1 = New LukeSw.Windows.Forms.Button
        Me.Button2 = New LukeSw.Windows.Forms.Button
        Me.Button3 = New LukeSw.Windows.Forms.Button
        Me.Button4 = New LukeSw.Windows.Forms.Button
        Me.Button5 = New LukeSw.Windows.Forms.Button
        Me.Button6 = New LukeSw.Windows.Forms.Button
        Me.Button7 = New LukeSw.Windows.Forms.Button
        Me.Button8 = New LukeSw.Windows.Forms.Button
        Me.Button9 = New LukeSw.Windows.Forms.Button
        Me.Button10 = New LukeSw.Windows.Forms.Button
        Me.Button11 = New LukeSw.Windows.Forms.Button
        Me.FlowLayoutPanelButtonsLeft = New System.Windows.Forms.FlowLayoutPanel
        Me.ButtonExpander = New LukeSw.Windows.Forms.ChevronButton
        Me.CheckBox = New System.Windows.Forms.CheckBox
        Me.BevelButtons = New System.Windows.Forms.Label
        Me.TableLayoutPanel = New System.Windows.Forms.TableLayoutPanel
        Me.TableLayoutPanelContent.SuspendLayout()
        Me.PanelExpandedFooter.SuspendLayout()
        Me.TableLayoutPanelExpanderFooter.SuspendLayout()
        Me.PanelFooter.SuspendLayout()
        Me.TableLayoutPanelFooter.SuspendLayout()
        Me.PanelButtons.SuspendLayout()
        Me.TableLayoutPanelButtons.SuspendLayout()
        Me.FlowLayoutPanelButtons.SuspendLayout()
        Me.FlowLayoutPanelButtonsLeft.SuspendLayout()
        Me.TableLayoutPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanelContent
        '
        Me.TableLayoutPanelContent.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanelContent.AutoSize = True
        Me.TableLayoutPanelContent.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanelContent.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.TableLayoutPanelContent.ColumnCount = 2
        Me.TableLayoutPanelContent.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanelContent.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelContent.Controls.Add(Me.LabelIcon, 0, 0)
        Me.TableLayoutPanelContent.Controls.Add(Me.LabelTitle, 1, 0)
        Me.TableLayoutPanelContent.Controls.Add(Me.LabelContent, 1, 1)
        Me.TableLayoutPanelContent.Controls.Add(Me.TableLayoutPanelContents, 1, 3)
        Me.TableLayoutPanelContent.Controls.Add(Me.LabelExpandedContent, 1, 2)
        Me.TableLayoutPanelContent.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanelContent.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanelContent.Name = "TableLayoutPanelContent"
        Me.TableLayoutPanelContent.RowCount = 4
        Me.TableLayoutPanelContent.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelContent.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelContent.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelContent.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelContent.Size = New System.Drawing.Size(1176, 117)
        Me.TableLayoutPanelContent.TabIndex = 0
        '
        'LabelIcon
        '
        Me.LabelIcon.BackColor = System.Drawing.Color.Transparent
        Me.LabelIcon.Location = New System.Drawing.Point(12, 12)
        Me.LabelIcon.Margin = New System.Windows.Forms.Padding(12, 12, 0, 12)
        Me.LabelIcon.Name = "LabelIcon"
        Me.TableLayoutPanelContent.SetRowSpan(Me.LabelIcon, 2)
        Me.LabelIcon.Size = New System.Drawing.Size(32, 32)
        Me.LabelIcon.TabIndex = 0
        '
        'LabelTitle
        '
        Me.LabelTitle.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelTitle.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.LabelTitle.AutoSize = True
        Me.LabelTitle.BackColor = System.Drawing.Color.Transparent
        Me.LabelTitle.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.LabelTitle.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.LabelTitle.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.LabelTitle.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.LabelTitle.LinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelTitle.Location = New System.Drawing.Point(53, 16)
        Me.LabelTitle.Margin = New System.Windows.Forms.Padding(9, 16, 16, 16)
        Me.LabelTitle.Name = "LabelTitle"
        Me.LabelTitle.Size = New System.Drawing.Size(77, 19)
        Me.LabelTitle.TabIndex = 1
        Me.LabelTitle.Text = "LabelTitle"
        '
        'LabelContent
        '
        Me.LabelContent.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelContent.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.LabelContent.AutoSize = True
        Me.LabelContent.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.LabelContent.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.LabelContent.LinkColor = System.Drawing.SystemColors.HotTrack
        Me.LabelContent.Location = New System.Drawing.Point(56, 59)
        Me.LabelContent.Margin = New System.Windows.Forms.Padding(12, 8, 16, 8)
        Me.LabelContent.Name = "LabelContent"
        Me.LabelContent.Size = New System.Drawing.Size(71, 13)
        Me.LabelContent.TabIndex = 2
        Me.LabelContent.Text = "LabelContent"
        Me.LabelContent.VisitedLinkColor = System.Drawing.SystemColors.HotTrack
        '
        'TableLayoutPanelContents
        '
        Me.TableLayoutPanelContents.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanelContents.AutoSize = True
        Me.TableLayoutPanelContents.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanelContents.ColumnCount = 1
        Me.TableLayoutPanelContents.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelContents.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanelContents.Location = New System.Drawing.Point(56, 109)
        Me.TableLayoutPanelContents.Margin = New System.Windows.Forms.Padding(12, 8, 16, 8)
        Me.TableLayoutPanelContents.Name = "TableLayoutPanelContents"
        Me.TableLayoutPanelContents.RowCount = 1
        Me.TableLayoutPanelContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelContents.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 1.0!))
        Me.TableLayoutPanelContents.Size = New System.Drawing.Size(1104, 0)
        Me.TableLayoutPanelContents.TabIndex = 3
        '
        'LabelExpandedContent
        '
        Me.LabelExpandedContent.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelExpandedContent.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.LabelExpandedContent.AutoSize = True
        Me.LabelExpandedContent.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.LabelExpandedContent.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.LabelExpandedContent.LinkColor = System.Drawing.SystemColors.HotTrack
        Me.LabelExpandedContent.Location = New System.Drawing.Point(56, 80)
        Me.LabelExpandedContent.Margin = New System.Windows.Forms.Padding(12, 0, 16, 8)
        Me.LabelExpandedContent.Name = "LabelExpandedContent"
        Me.LabelExpandedContent.Size = New System.Drawing.Size(119, 13)
        Me.LabelExpandedContent.TabIndex = 2
        Me.LabelExpandedContent.Text = "LabelExpandedContent"
        Me.LabelExpandedContent.VisitedLinkColor = System.Drawing.SystemColors.HotTrack
        '
        'PanelExpandedFooter
        '
        Me.PanelExpandedFooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelExpandedFooter.AutoSize = True
        Me.PanelExpandedFooter.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelExpandedFooter.Controls.Add(Me.TableLayoutPanelExpanderFooter)
        Me.PanelExpandedFooter.Controls.Add(Me.BevelExpanderFooter)
        Me.PanelExpandedFooter.Location = New System.Drawing.Point(0, 218)
        Me.PanelExpandedFooter.Margin = New System.Windows.Forms.Padding(0)
        Me.PanelExpandedFooter.Name = "PanelExpandedFooter"
        Me.PanelExpandedFooter.Size = New System.Drawing.Size(1176, 31)
        Me.PanelExpandedFooter.TabIndex = 3
        '
        'TableLayoutPanelExpanderFooter
        '
        Me.TableLayoutPanelExpanderFooter.AutoSize = True
        Me.TableLayoutPanelExpanderFooter.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanelExpanderFooter.ColumnCount = 1
        Me.TableLayoutPanelExpanderFooter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanelExpanderFooter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20.0!))
        Me.TableLayoutPanelExpanderFooter.Controls.Add(Me.LabelExpandedFooter, 0, 0)
        Me.TableLayoutPanelExpanderFooter.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanelExpanderFooter.Location = New System.Drawing.Point(0, 2)
        Me.TableLayoutPanelExpanderFooter.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanelExpanderFooter.Name = "TableLayoutPanelExpanderFooter"
        Me.TableLayoutPanelExpanderFooter.RowCount = 1
        Me.TableLayoutPanelExpanderFooter.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelExpanderFooter.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 29.0!))
        Me.TableLayoutPanelExpanderFooter.Size = New System.Drawing.Size(1176, 29)
        Me.TableLayoutPanelExpanderFooter.TabIndex = 1
        '
        'LabelExpandedFooter
        '
        Me.LabelExpandedFooter.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelExpandedFooter.AutoSize = True
        Me.LabelExpandedFooter.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.LabelExpandedFooter.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.LabelExpandedFooter.LinkColor = System.Drawing.SystemColors.HotTrack
        Me.LabelExpandedFooter.Location = New System.Drawing.Point(16, 8)
        Me.LabelExpandedFooter.Margin = New System.Windows.Forms.Padding(16, 8, 16, 8)
        Me.LabelExpandedFooter.Name = "LabelExpandedFooter"
        Me.LabelExpandedFooter.Size = New System.Drawing.Size(112, 13)
        Me.LabelExpandedFooter.TabIndex = 1
        Me.LabelExpandedFooter.Text = "LabelExpandedFooter"
        Me.LabelExpandedFooter.VisitedLinkColor = System.Drawing.SystemColors.HotTrack
        '
        'BevelExpanderFooter
        '
        Me.BevelExpanderFooter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.BevelExpanderFooter.Dock = System.Windows.Forms.DockStyle.Top
        Me.BevelExpanderFooter.Location = New System.Drawing.Point(0, 0)
        Me.BevelExpanderFooter.Name = "BevelExpanderFooter"
        Me.BevelExpanderFooter.Size = New System.Drawing.Size(1176, 2)
        Me.BevelExpanderFooter.TabIndex = 0
        '
        'PanelFooter
        '
        Me.PanelFooter.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelFooter.AutoSize = True
        Me.PanelFooter.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelFooter.Controls.Add(Me.TableLayoutPanelFooter)
        Me.PanelFooter.Controls.Add(Me.BevelFooter)
        Me.PanelFooter.Location = New System.Drawing.Point(0, 186)
        Me.PanelFooter.Margin = New System.Windows.Forms.Padding(0)
        Me.PanelFooter.Name = "PanelFooter"
        Me.PanelFooter.Size = New System.Drawing.Size(1176, 32)
        Me.PanelFooter.TabIndex = 2
        '
        'TableLayoutPanelFooter
        '
        Me.TableLayoutPanelFooter.AutoSize = True
        Me.TableLayoutPanelFooter.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanelFooter.ColumnCount = 2
        Me.TableLayoutPanelFooter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanelFooter.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelFooter.Controls.Add(Me.LabelIconFooter, 0, 0)
        Me.TableLayoutPanelFooter.Controls.Add(Me.LabelFooter, 1, 0)
        Me.TableLayoutPanelFooter.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanelFooter.Location = New System.Drawing.Point(0, 2)
        Me.TableLayoutPanelFooter.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanelFooter.Name = "TableLayoutPanelFooter"
        Me.TableLayoutPanelFooter.RowCount = 1
        Me.TableLayoutPanelFooter.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelFooter.Size = New System.Drawing.Size(1176, 30)
        Me.TableLayoutPanelFooter.TabIndex = 1
        '
        'LabelIconFooter
        '
        Me.LabelIconFooter.Location = New System.Drawing.Point(16, 6)
        Me.LabelIconFooter.Margin = New System.Windows.Forms.Padding(16, 6, 0, 8)
        Me.LabelIconFooter.Name = "LabelIconFooter"
        Me.LabelIconFooter.Size = New System.Drawing.Size(16, 16)
        Me.LabelIconFooter.TabIndex = 0
        '
        'LabelFooter
        '
        Me.LabelFooter.ActiveLinkColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(102, Byte), Integer), CType(CType(204, Byte), Integer))
        Me.LabelFooter.AutoSize = True
        Me.LabelFooter.DisabledLinkColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(133, Byte), Integer), CType(CType(156, Byte), Integer))
        Me.LabelFooter.LinkArea = New System.Windows.Forms.LinkArea(0, 0)
        Me.LabelFooter.LinkColor = System.Drawing.SystemColors.HotTrack
        Me.LabelFooter.Location = New System.Drawing.Point(36, 8)
        Me.LabelFooter.Margin = New System.Windows.Forms.Padding(4, 8, 16, 8)
        Me.LabelFooter.Name = "LabelFooter"
        Me.LabelFooter.Size = New System.Drawing.Size(64, 13)
        Me.LabelFooter.TabIndex = 0
        Me.LabelFooter.Text = "LabelFooter"
        Me.LabelFooter.VisitedLinkColor = System.Drawing.SystemColors.HotTrack
        '
        'BevelFooter
        '
        Me.BevelFooter.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.BevelFooter.Dock = System.Windows.Forms.DockStyle.Top
        Me.BevelFooter.Location = New System.Drawing.Point(0, 0)
        Me.BevelFooter.Name = "BevelFooter"
        Me.BevelFooter.Size = New System.Drawing.Size(1176, 2)
        Me.BevelFooter.TabIndex = 0
        '
        'PanelButtons
        '
        Me.PanelButtons.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.PanelButtons.AutoSize = True
        Me.PanelButtons.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelButtons.Controls.Add(Me.TableLayoutPanelButtons)
        Me.PanelButtons.Controls.Add(Me.BevelButtons)
        Me.PanelButtons.Location = New System.Drawing.Point(0, 117)
        Me.PanelButtons.Margin = New System.Windows.Forms.Padding(0)
        Me.PanelButtons.Name = "PanelButtons"
        Me.PanelButtons.Size = New System.Drawing.Size(1176, 69)
        Me.PanelButtons.TabIndex = 1
        '
        'TableLayoutPanelButtons
        '
        Me.TableLayoutPanelButtons.AutoSize = True
        Me.TableLayoutPanelButtons.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanelButtons.ColumnCount = 2
        Me.TableLayoutPanelButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanelButtons.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100.0!))
        Me.TableLayoutPanelButtons.Controls.Add(Me.FlowLayoutPanelButtons, 1, 0)
        Me.TableLayoutPanelButtons.Controls.Add(Me.FlowLayoutPanelButtonsLeft, 0, 0)
        Me.TableLayoutPanelButtons.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanelButtons.Location = New System.Drawing.Point(0, 2)
        Me.TableLayoutPanelButtons.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanelButtons.Name = "TableLayoutPanelButtons"
        Me.TableLayoutPanelButtons.RowCount = 1
        Me.TableLayoutPanelButtons.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanelButtons.Size = New System.Drawing.Size(1176, 67)
        Me.TableLayoutPanelButtons.TabIndex = 1
        '
        'FlowLayoutPanelButtons
        '
        Me.FlowLayoutPanelButtons.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FlowLayoutPanelButtons.AutoSize = True
        Me.FlowLayoutPanelButtons.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button1)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button2)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button3)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button4)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button5)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button6)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button7)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button8)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button9)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button10)
        Me.FlowLayoutPanelButtons.Controls.Add(Me.Button11)
        Me.FlowLayoutPanelButtons.Location = New System.Drawing.Point(255, 4)
        Me.FlowLayoutPanelButtons.Margin = New System.Windows.Forms.Padding(8, 4, 8, 4)
        Me.FlowLayoutPanelButtons.Name = "FlowLayoutPanelButtons"
        Me.FlowLayoutPanelButtons.Size = New System.Drawing.Size(913, 33)
        Me.FlowLayoutPanelButtons.TabIndex = 0
        Me.FlowLayoutPanelButtons.WrapContents = False
        '
        'Button1
        '
        Me.Button1.AutoSize = True
        Me.Button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button1.Location = New System.Drawing.Point(4, 4)
        Me.Button1.Margin = New System.Windows.Forms.Padding(4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 25)
        Me.Button1.TabIndex = 0
        Me.Button1.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button1.Visible = False
        '
        'Button2
        '
        Me.Button2.AutoSize = True
        Me.Button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button2.Location = New System.Drawing.Point(87, 4)
        Me.Button2.Margin = New System.Windows.Forms.Padding(4)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 25)
        Me.Button2.TabIndex = 1
        Me.Button2.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button2.Visible = False
        '
        'Button3
        '
        Me.Button3.AutoSize = True
        Me.Button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button3.Location = New System.Drawing.Point(170, 4)
        Me.Button3.Margin = New System.Windows.Forms.Padding(4)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 25)
        Me.Button3.TabIndex = 2
        Me.Button3.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button3.Visible = False
        '
        'Button4
        '
        Me.Button4.AutoSize = True
        Me.Button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button4.Location = New System.Drawing.Point(253, 4)
        Me.Button4.Margin = New System.Windows.Forms.Padding(4)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 25)
        Me.Button4.TabIndex = 3
        Me.Button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button4.Visible = False
        '
        'Button5
        '
        Me.Button5.AutoSize = True
        Me.Button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button5.Location = New System.Drawing.Point(336, 4)
        Me.Button5.Margin = New System.Windows.Forms.Padding(4)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(75, 25)
        Me.Button5.TabIndex = 4
        Me.Button5.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button5.Visible = False
        '
        'Button6
        '
        Me.Button6.AutoSize = True
        Me.Button6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button6.Location = New System.Drawing.Point(419, 4)
        Me.Button6.Margin = New System.Windows.Forms.Padding(4)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 25)
        Me.Button6.TabIndex = 5
        Me.Button6.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button6.Visible = False
        '
        'Button7
        '
        Me.Button7.AutoSize = True
        Me.Button7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button7.Location = New System.Drawing.Point(502, 4)
        Me.Button7.Margin = New System.Windows.Forms.Padding(4)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 25)
        Me.Button7.TabIndex = 6
        Me.Button7.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button7.Visible = False
        '
        'Button8
        '
        Me.Button8.AutoSize = True
        Me.Button8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button8.Location = New System.Drawing.Point(585, 4)
        Me.Button8.Margin = New System.Windows.Forms.Padding(4)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(75, 25)
        Me.Button8.TabIndex = 7
        Me.Button8.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button8.Visible = False
        '
        'Button9
        '
        Me.Button9.AutoSize = True
        Me.Button9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button9.Location = New System.Drawing.Point(668, 4)
        Me.Button9.Margin = New System.Windows.Forms.Padding(4)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(75, 25)
        Me.Button9.TabIndex = 8
        Me.Button9.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button9.Visible = False
        '
        'Button10
        '
        Me.Button10.AutoSize = True
        Me.Button10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button10.Location = New System.Drawing.Point(751, 4)
        Me.Button10.Margin = New System.Windows.Forms.Padding(4)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(75, 25)
        Me.Button10.TabIndex = 9
        Me.Button10.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button10.Visible = False
        '
        'Button11
        '
        Me.Button11.AutoSize = True
        Me.Button11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button11.Location = New System.Drawing.Point(834, 4)
        Me.Button11.Margin = New System.Windows.Forms.Padding(4)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 25)
        Me.Button11.TabIndex = 10
        Me.Button11.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.Button11.Visible = False
        '
        'FlowLayoutPanelButtonsLeft
        '
        Me.FlowLayoutPanelButtonsLeft.Anchor = System.Windows.Forms.AnchorStyles.Left
        Me.FlowLayoutPanelButtonsLeft.AutoSize = True
        Me.FlowLayoutPanelButtonsLeft.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.FlowLayoutPanelButtonsLeft.Controls.Add(Me.ButtonExpander)
        Me.FlowLayoutPanelButtonsLeft.Controls.Add(Me.CheckBox)
        Me.FlowLayoutPanelButtonsLeft.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanelButtonsLeft.Location = New System.Drawing.Point(8, 4)
        Me.FlowLayoutPanelButtonsLeft.Margin = New System.Windows.Forms.Padding(8, 4, 4, 4)
        Me.FlowLayoutPanelButtonsLeft.Name = "FlowLayoutPanelButtonsLeft"
        Me.FlowLayoutPanelButtonsLeft.Size = New System.Drawing.Size(196, 59)
        Me.FlowLayoutPanelButtonsLeft.TabIndex = 1
        '
        'ButtonExpander
        '
        Me.ButtonExpander.AutoSize = True
        Me.ButtonExpander.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ButtonExpander.BackColor = System.Drawing.Color.Transparent
        Me.ButtonExpander.Expanded = False
        Me.ButtonExpander.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.ButtonExpander.FlatAppearance.BorderSize = 0
        Me.ButtonExpander.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent
        Me.ButtonExpander.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent
        Me.ButtonExpander.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonExpander.Image = CType(resources.GetObject("ButtonExpander.Image"), System.Drawing.Image)
        Me.ButtonExpander.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonExpander.Location = New System.Drawing.Point(0, 4)
        Me.ButtonExpander.Margin = New System.Windows.Forms.Padding(0, 4, 8, 4)
        Me.ButtonExpander.Name = "ButtonExpander"
        Me.ButtonExpander.Size = New System.Drawing.Size(90, 26)
        Me.ButtonExpander.TabIndex = 0
        Me.ButtonExpander.Text = "Show More"
        Me.ButtonExpander.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.ButtonExpander.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.ButtonExpander.UseVisualStyleBackColor = False
        Me.ButtonExpander.Visible = False
        '
        'CheckBox
        '
        Me.CheckBox.AutoSize = True
        Me.CheckBox.Location = New System.Drawing.Point(8, 38)
        Me.CheckBox.Margin = New System.Windows.Forms.Padding(8, 4, 8, 4)
        Me.CheckBox.Name = "CheckBox"
        Me.CheckBox.Size = New System.Drawing.Size(180, 17)
        Me.CheckBox.TabIndex = 1
        Me.CheckBox.Text = "Do not show this message again"
        Me.CheckBox.UseVisualStyleBackColor = True
        '
        'BevelButtons
        '
        Me.BevelButtons.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.BevelButtons.Dock = System.Windows.Forms.DockStyle.Top
        Me.BevelButtons.Location = New System.Drawing.Point(0, 0)
        Me.BevelButtons.Name = "BevelButtons"
        Me.BevelButtons.Size = New System.Drawing.Size(1176, 2)
        Me.BevelButtons.TabIndex = 0
        '
        'TableLayoutPanel
        '
        Me.TableLayoutPanel.AutoSize = True
        Me.TableLayoutPanel.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.TableLayoutPanel.ColumnCount = 1
        Me.TableLayoutPanel.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle)
        Me.TableLayoutPanel.Controls.Add(Me.TableLayoutPanelContent, 0, 0)
        Me.TableLayoutPanel.Controls.Add(Me.PanelButtons, 0, 1)
        Me.TableLayoutPanel.Controls.Add(Me.PanelFooter, 0, 2)
        Me.TableLayoutPanel.Controls.Add(Me.PanelExpandedFooter, 0, 3)
        Me.TableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel.Margin = New System.Windows.Forms.Padding(0)
        Me.TableLayoutPanel.Name = "TableLayoutPanel"
        Me.TableLayoutPanel.RowCount = 4
        Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanel.RowStyles.Add(New System.Windows.Forms.RowStyle)
        Me.TableLayoutPanel.Size = New System.Drawing.Size(1176, 610)
        Me.TableLayoutPanel.TabIndex = 0
        '
        'VDialogForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(1176, 610)
        Me.Controls.Add(Me.TableLayoutPanel)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "VDialogForm"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "VDialogForm"
        Me.TableLayoutPanelContent.ResumeLayout(False)
        Me.TableLayoutPanelContent.PerformLayout()
        Me.PanelExpandedFooter.ResumeLayout(False)
        Me.PanelExpandedFooter.PerformLayout()
        Me.TableLayoutPanelExpanderFooter.ResumeLayout(False)
        Me.TableLayoutPanelExpanderFooter.PerformLayout()
        Me.PanelFooter.ResumeLayout(False)
        Me.PanelFooter.PerformLayout()
        Me.TableLayoutPanelFooter.ResumeLayout(False)
        Me.TableLayoutPanelFooter.PerformLayout()
        Me.PanelButtons.ResumeLayout(False)
        Me.PanelButtons.PerformLayout()
        Me.TableLayoutPanelButtons.ResumeLayout(False)
        Me.TableLayoutPanelButtons.PerformLayout()
        Me.FlowLayoutPanelButtons.ResumeLayout(False)
        Me.FlowLayoutPanelButtons.PerformLayout()
        Me.FlowLayoutPanelButtonsLeft.ResumeLayout(False)
        Me.FlowLayoutPanelButtonsLeft.PerformLayout()
        Me.TableLayoutPanel.ResumeLayout(False)
        Me.TableLayoutPanel.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PanelExpandedFooter As System.Windows.Forms.Panel
    Friend WithEvents PanelFooter As System.Windows.Forms.Panel
    Friend WithEvents PanelButtons As System.Windows.Forms.Panel
    Friend WithEvents BevelExpanderFooter As System.Windows.Forms.Label
    Friend WithEvents BevelFooter As System.Windows.Forms.Label
    Friend WithEvents BevelButtons As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanelContent As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LabelIcon As System.Windows.Forms.Label
    Friend WithEvents LabelTitle As LukeSw.Windows.Forms.Label
    Friend WithEvents LabelContent As LukeSw.Windows.Forms.Label
    Friend WithEvents TableLayoutPanelContents As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanelFooter As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LabelIconFooter As System.Windows.Forms.Label
    Friend WithEvents LabelFooter As LukeSw.Windows.Forms.Label
    Friend WithEvents LabelExpandedFooter As LukeSw.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanelButtons As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Button1 As LukeSw.Windows.Forms.Button
    Friend WithEvents TableLayoutPanelButtons As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Button2 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button3 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button4 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button5 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button6 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button7 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button8 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button9 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button10 As LukeSw.Windows.Forms.Button
    Friend WithEvents Button11 As LukeSw.Windows.Forms.Button
    Friend WithEvents TableLayoutPanelExpanderFooter As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LabelExpandedContent As LukeSw.Windows.Forms.Label
    Friend WithEvents FlowLayoutPanelButtonsLeft As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents ButtonExpander As LukeSw.Windows.Forms.ChevronButton
    Friend WithEvents CheckBox As System.Windows.Forms.CheckBox
End Class
