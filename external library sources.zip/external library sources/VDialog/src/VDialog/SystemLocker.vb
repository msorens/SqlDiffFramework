﻿Imports System.Threading
Imports System.Runtime.InteropServices

Public Module SystemLocker

    Public Sub ShowDialog(Of TForm As Form)(ByVal owner As Control, <Out()> ByRef form As TForm)

        Dim screen As Screen = [If](owner Is Nothing, screen.PrimaryScreen, screen.FromControl(owner))
        Dim background As Bitmap = New Bitmap(screen.Bounds.Width, screen.Bounds.Height)
        Using g As Graphics = Graphics.FromImage(background)

            g.CopyFromScreen(0, 0, 0, 0, screen.Bounds.Size)
            Using br As Brush = New SolidBrush(Color.FromArgb(192, Color.Black))
                g.FillRectangle(br, screen.Bounds)
            End Using

            If owner IsNot Nothing Then
                Dim f As Form = owner.FindForm()
                g.CopyFromScreen(f.Location, form.Location, form.Size)
                Using br As Brush = New SolidBrush(Color.FromArgb(128, Color.Black))
                    g.FillRectangle(br, New Rectangle(f.Location, form.Size))
                End Using
            End If

            Dim originalThread As IntPtr
            Dim originalInput As IntPtr
            Dim newDesktop As IntPtr

            originalThread = GetThreadDesktop(Thread.CurrentThread.ManagedThreadId)
            originalInput = OpenInputDesktop(0, False, DESKTOP_SWITCHDESKTOP)

            newDesktop = CreateDesktop("Desktop" & Guid.NewGuid().ToString(), Nothing, Nothing, 0, GENERIC_ALL, Nothing)
            SetThreadDesktop(newDesktop)
            SwitchDesktop(newDesktop)

            Dim newThread As Thread = New Thread(AddressOf NewThreadMethod)
            newThread.CurrentCulture = Thread.CurrentThread.CurrentCulture
            newThread.CurrentUICulture = Thread.CurrentThread.CurrentUICulture
            newThread.Start(New VDialogLockSystemParameters(newDesktop, background))
            newThread.Join()

            SwitchDesktop(originalInput)
            SetThreadDesktop(originalThread)

            CloseDesktop(newDesktop)
            CloseDesktop(originalInput)
        End Using

    End Sub

    Private Sub NewThreadMethod(ByVal params As Object)
        Dim v As VDialogLockSystemParameters = DirectCast(params, VDialogLockSystemParameters)
        SetThreadDesktop(v.NewDesktop)
        Using f As Form = New BackgroundForm(v.Background)
            f.Show()
            ShowInternal(f)
            f.BackgroundImage = Nothing
            Application.DoEvents()
            Thread.Sleep(250)
        End Using
    End Sub

End Module
