using System.Collections;
using System.Collections.ObjectModel;

namespace UrielGuy.SyntaxHighlightingTextBox
{
    // 2009.03.01 Sorens: Discarded virtually everything--
    // just the class definition line and one method are needed.
    /// <summary>
	/// Summary description for SeparatorCollection.
	/// </summary>
	public class SeparatorCollection : Collection<char>
	{
        internal char[] GetAsCharArray()
        {
            return (char[])new ArrayList(this).ToArray(typeof(char));
        }
	}
}
