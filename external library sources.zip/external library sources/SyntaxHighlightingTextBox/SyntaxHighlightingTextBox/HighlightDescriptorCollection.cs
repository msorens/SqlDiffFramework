using System.Collections.ObjectModel;

namespace UrielGuy.SyntaxHighlightingTextBox
{
    // 2009.03.01 Sorens: Discarded virtually everything--just the class definition line is needed.
    /// <summary>
    /// Summary description for HighLightDescriptorCollection.
	/// </summary>
    /// 
    public class HighLightDescriptorCollection : Collection<HighlightDescriptor>
    {
    }

}
