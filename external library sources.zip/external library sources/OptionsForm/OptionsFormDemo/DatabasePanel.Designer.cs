namespace OptionsFormDemo
{
    partial class DatabasePanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.checkBox1);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(340, 88);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Database File";
            // 
            // checkBox1
            // 
            this.checkBox1.AccessibleDescription = "Indicates if the database file need to be modified by the application.";
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = global::OptionsFormDemo.Properties.Settings.Default.OpenDatabaseEditMode;
            this.checkBox1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::OptionsFormDemo.Properties.Settings.Default, "OpenDatabaseEditMode", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox1.Location = new System.Drawing.Point(6, 62);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(175, 17);
            this.checkBox1.TabIndex = 2;
            this.checkBox1.Text = "Open database file in edit mode";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.AccessibleDescription = "Click here to select a database file.";
            this.button1.Location = new System.Drawing.Point(296, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(38, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.AccessibleDescription = "The database file location.";
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::OptionsFormDemo.Properties.Settings.Default, "DatabaseFileName", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.textBox1.Location = new System.Drawing.Point(6, 28);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(287, 20);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = global::OptionsFormDemo.Properties.Settings.Default.DatabaseFileName;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Access Database|*.mdb|All Files|*.*";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.numericUpDown3);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.numericUpDown2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.numericUpDown1);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Enabled = global::OptionsFormDemo.Properties.Settings.Default.OpenDatabaseEditMode;
            this.groupBox2.Location = new System.Drawing.Point(0, 94);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(340, 110);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "EditMode";
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.DataBindings.Add(new System.Windows.Forms.Binding("Value", global::OptionsFormDemo.Properties.Settings.Default, "EditMaxRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown3.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanEditRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown3.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanEditRows;
            this.numericUpDown3.Location = new System.Drawing.Point(272, 79);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(62, 20);
            this.numericUpDown3.TabIndex = 8;
            this.numericUpDown3.Value = global::OptionsFormDemo.Properties.Settings.Default.EditMaxRows;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanEditRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.label3.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanEditRows;
            this.label3.Location = new System.Drawing.Point(164, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Max number of rows";
            // 
            // checkBox4
            // 
            this.checkBox4.AccessibleDescription = "Indicates if the user can edit rows in the database.";
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = global::OptionsFormDemo.Properties.Settings.Default.UserCanEditRows;
            this.checkBox4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::OptionsFormDemo.Properties.Settings.Default, "UserCanEditRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox4.Location = new System.Drawing.Point(6, 80);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(134, 17);
            this.checkBox4.TabIndex = 6;
            this.checkBox4.Text = "The user can edit rows";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.DataBindings.Add(new System.Windows.Forms.Binding("Value", global::OptionsFormDemo.Properties.Settings.Default, "DelMaxRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown2.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanDelRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown2.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanDelRows;
            this.numericUpDown2.Location = new System.Drawing.Point(272, 53);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(62, 20);
            this.numericUpDown2.TabIndex = 5;
            this.numericUpDown2.Value = global::OptionsFormDemo.Properties.Settings.Default.DelMaxRows;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanDelRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.label2.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanDelRows;
            this.label2.Location = new System.Drawing.Point(164, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Max number of rows";
            // 
            // checkBox3
            // 
            this.checkBox3.AccessibleDescription = "Indicates if the user can delete rows from the database.";
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = global::OptionsFormDemo.Properties.Settings.Default.UserCanDelRows;
            this.checkBox3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::OptionsFormDemo.Properties.Settings.Default, "UserCanDelRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox3.Location = new System.Drawing.Point(6, 54);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(146, 17);
            this.checkBox3.TabIndex = 3;
            this.checkBox3.Text = "The user can delete rows";
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DataBindings.Add(new System.Windows.Forms.Binding("Value", global::OptionsFormDemo.Properties.Settings.Default, "AddMaxRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown1.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanAddRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.numericUpDown1.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanAddRows;
            this.numericUpDown1.Location = new System.Drawing.Point(272, 27);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(62, 20);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.Value = global::OptionsFormDemo.Properties.Settings.Default.AddMaxRows;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.DataBindings.Add(new System.Windows.Forms.Binding("Enabled", global::OptionsFormDemo.Properties.Settings.Default, "UserCanAddRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.label1.Enabled = global::OptionsFormDemo.Properties.Settings.Default.UserCanAddRows;
            this.label1.Location = new System.Drawing.Point(164, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Max number of rows";
            // 
            // checkBox2
            // 
            this.checkBox2.AccessibleDescription = "Indicates if the user can add new rows to the database.";
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = global::OptionsFormDemo.Properties.Settings.Default.UserCanAddRows;
            this.checkBox2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::OptionsFormDemo.Properties.Settings.Default, "UserCanAddRows", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox2.Location = new System.Drawing.Point(6, 28);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(135, 17);
            this.checkBox2.TabIndex = 0;
            this.checkBox2.Text = "The user can add rows";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // DatabasePanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.CategoryPath = "Options\\Sub\\Database";
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.DisplayName = "Storage Info";
            this.Location = new System.Drawing.Point(0, 0);
            this.Name = "DatabasePanel";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox checkBox3;
    }
}
