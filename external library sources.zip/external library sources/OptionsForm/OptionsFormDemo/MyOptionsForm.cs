using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace OptionsFormDemo
{
    public partial class MyOptionsForm : GLib.Options.OptionsForm
    {
        public MyOptionsForm() : base(Properties.Settings.Default)
        {
            InitializeComponent();

            Panels.Add(new GeneralPanel());
            Panels.Add(new DatabasePanel());
        }
    }
}

