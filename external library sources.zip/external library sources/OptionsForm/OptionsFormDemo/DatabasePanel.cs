using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace OptionsFormDemo
{
    public partial class DatabasePanel : GLib.Options.OptionsPanel
    {
        public DatabasePanel()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog(this) == DialogResult.OK 
                && File.Exists(openFileDialog1.FileName))
            {
                textBox1.Text = openFileDialog1.FileName;
                ApplicationMustRestart = true;
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            groupBox2.Enabled = checkBox1.Checked;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Enabled = checkBox2.Checked;
            numericUpDown1.Enabled = checkBox2.Checked;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            label2.Enabled = checkBox3.Checked;
            numericUpDown2.Enabled = checkBox3.Checked;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            label3.Enabled = checkBox4.Checked;
            numericUpDown3.Enabled = checkBox4.Checked;
        }
    }
}

