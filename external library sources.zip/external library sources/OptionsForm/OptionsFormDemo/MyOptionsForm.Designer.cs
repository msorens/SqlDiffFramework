namespace OptionsFormDemo
{
    partial class MyOptionsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MyOptionsForm));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Options");
            this.imageList1.Images.SetKeyName(1, "Options\\Sub\\General");
            this.imageList1.Images.SetKeyName(2, "Options\\Sub\\Database");
            // 
            // MyOptionsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.CategoryImages = this.imageList1;
            this.CategoryTreeWidth = 160;
            this.ClientSize = new System.Drawing.Size(512, 375);
            this.MinimumSize = new System.Drawing.Size(518, 407);
            this.Name = "MyOptionsForm";
            this.ShowCategoryDescription = true;
            this.ShowCategoryHeader = true;
            this.ShowOptionsPanelPath = true;
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;

    }
}
